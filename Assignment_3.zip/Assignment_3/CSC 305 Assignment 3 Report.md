#### CSC 305 Assignment 3 Report

###### Ex 0 Intersection Code

*ray_sphere_intersection, ray_parallelogram_intersection, ray_pgram_parameters* modified

###### Ex 1 Field of View and Perspective Camera

image_y and image_x computed,  perspective camera implemented (modification of ray origin and direction)

###### Ex 2 Shadow Rays

*is_light_visible* implemented and specular contribution computed, shadow rays use *is_light_visible* to determine affected points

###### Ex 3 Reflection

*shoot_ray* modified

Note: Reflection vector is negated, -r (as computed in main.cpp) results in a seg fault.

###### Ex 4 Perlin Noise

incomplete

 